// ========== 取出对方文字（只用 JSON 消息段）==========
//
// event          = 这一次「有人发了消息」整包数据
// event.message  = 消息内容，推荐是「消息段」数组
// 消息段例子：[{ type: 'text', data: { text: '你好' } }]
//   type = 这一段是什么类型（'text' = 纯文字）
//   data = 这一段的具体内容
//   data.text = 文字本身
//
// 千万不要用 raw_message，也不要自己解析 [CQ:...] 字符串
// CQ 码不稳定，用久了容易出怪问题

// let = 声明一个可以改的变量
// text = 我们自己起的名字，用来装「拼好的纯文字」
let text = '';

// const = 声明一个一般不再改绑定的变量
// Array.isArray(x) = 判断 x 是不是数组；是就用 event.message，否则用空数组 []
// ? … : … = 三元运算：「条件成立用左边，否则用右边」
const parts = Array.isArray(event.message) ? event.message : [];

// for…of = 把数组里每一项依次拿出来，名字叫 part
for (const part of parts) {
  // && = 并且（左边成立才继续看右边）
  // 如果这一段存在、类型是 text、且 data.text 有值，就把文字拼进去
  if (part && part.type === 'text' && part.data && part.data.text) {
    // String(...) = 强制变成字符串，避免偶发数字类型
    // + = 字符串拼接
    text = text + String(part.data.text);
  }
}

// 以后判断指令时，都用这个 text 去比
